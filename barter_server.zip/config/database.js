// config/database.js
module.exports = {

	'barter_url' : 'mongodb://localhost:27017/barter' ,
	'climbtime_url' : 'mongodb://localhost:27017/climbtime'
};


